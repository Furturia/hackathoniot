type ENV_Data = {
	backend_url: string;
};

const environment: ENV_Data = {
	backend_url: 'http://localhost:4000',
};

export { environment };
